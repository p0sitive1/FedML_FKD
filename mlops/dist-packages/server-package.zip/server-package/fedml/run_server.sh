#!/usr/bin/env bash

python torch_server.py --cf config/fedml_config.yaml --rank 0 --run_id 189